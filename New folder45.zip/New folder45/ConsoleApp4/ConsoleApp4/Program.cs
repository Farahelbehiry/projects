﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {

       /* public class Student
        {
            int _stuId = 0;
            string _firstName = String.Empty;
            string _lastName = String.Empty;
            decimal _loanAmount = 0;
            char _gender = '\0';
            bool _isNew = false;
            public Student(int stuId, string firstName, string lastName, decimal loanAmount, char gender, bool isNew)
            {
                _stuId = stuId;
                _firstName = firstName;
                _lastName = lastName;
                _loanAmount = loanAmount;
                _gender = gender;
                _isNew = isNew;
            }
            public void UpdateLoanAmount(decimal loanAmount)
            {
                _loanAmount = loanAmount;
            }
            public string StudentData()
            {
                string studentData = $"stuId: {_stuId}, firstName: {_firstName}, loan Amount: {_loanAmount}";
                return studentData;
            }*/

            static void Main(string[] args)
            {
            /*Console.WriteLine("please entre your name:");
            var name = Console.ReadLine();
            Console.WriteLine($"Hello { name}");
            Console.ReadKey();*/

            //////////////////////////////
            /// 
            /* int employeeId =0;
             string firstName = string.Empty;
             string lastName = string.Empty;
             decimal employeeSalary = 0;
             char gender = '\0';
             bool isManager = false;
             Console.WriteLine("please entre a unique Id for this employee");
             employeeId = Convert.ToInt32(Console.ReadLine());


             Console.WriteLine("please entre the employee's first name");
             firstName = Console.ReadLine();

             Console.WriteLine("please entre the employee;s last name");
             lastName = Console.ReadLine();

             Console.WriteLine("please entre the employee's salary");
             employeeSalary = Convert.ToDecimal(Console.ReadLine());

             Console.WriteLine("please entre the gengre");
             gender= Convert.ToChar(Console.ReadLine());

             Console.WriteLine("the employee is a manager (true/false)");
             isManager =Convert.ToBoolean(Console.ReadLine());

             string gendreTerm = (gender == 'f') ? "female" : "male";
             string managerNarrative = (isManager) ? "part of the management team" : "curently not part of management team";

             string narrative =$"Emplyee with an Id of {employeeId} ";
             narrative += $"whose full name is {firstName} {lastName}{Environment.NewLine}";
             narrative += $"is a {gendreTerm} employee who is {managerNarrative}{Environment.NewLine}";
             narrative += $"This employee earns an annual salary of {employeeSalary}";


             Console.Clear();

             Console.WriteLine(narrative);
             Console.ReadKey();*/


            ////////////////////////////////////////////////////

            /* int stuId = 0;
             string firstName = string.Empty;
             string lastName = string.Empty;
             decimal loanAmount = 0;
             char gender = '\0';
             bool isNew = false;
             Console.WriteLine("Please enter the student Id");
             stuId = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("Please enter the student's first name");
             firstName = Console.ReadLine();
             Console.WriteLine("Please enter the student's last name");
             lastName = Console.ReadLine();
             Console.WriteLine("Please enter the student's loan amount");
             loanAmount = Decimal.Parse(Console.ReadLine(), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
             Console.WriteLine("Please enter the student's gender ('f' = female, 'm' = male)");
             gender = Convert.ToChar(Console.ReadLine());
             Console.WriteLine("The student is new (true/false)");
             isNew = Convert.ToBoolean(Console.ReadLine());
             Student student = new Student(stuId, firstName, lastName, loanAmount, gender, isNew);
             Console.Clear();
             Student studentCopy = student;
             Console.WriteLine("Student data  " + student.StudentData());
             Console.WriteLine();
             Console.WriteLine("Student copy data  " + studentCopy.StudentData());
             Console.WriteLine();
             Console.WriteLine("Please update the student's loan amount");
             student.UpdateLoanAmount(Convert.ToDecimal(Console.ReadLine()));
             string dividerText = "After loan update";
             Console.WriteLine(new String('-', dividerText.Length));
             Console.WriteLine(dividerText);
             Console.WriteLine(new String('-', dividerText.Length));
             Console.WriteLine("Student data  " + student.StudentData());
             Console.WriteLine();
             Console.WriteLine("Student copy data  " + studentCopy.StudentData());
             Console.ReadKey();*/

             ///////////
             /*string dividerText = "After loan update";
             Console.WriteLine(new String('-', dividerText.Length));
             Console.WriteLine(dividerText);
             Console.WriteLine(new String('-', dividerText.Length));
             Console.ReadKey();*/



        }
        }
    }

