﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Complex
    {
        private double realPart;
        private double imaginaryPart;
        public Complex(double real,double imag) 
        { 
            realPart = real;
            imaginaryPart = imag;

        }
        public Complex()
        {

        }
        public double RealPart
        {
            get { return realPart; }
        }
        public double ImaginaryPart
        {
            get { return imaginaryPart; }
        }
        public static Complex Addnum(Complex x,Complex y)
        {
            double real = x.realPart + y.realPart;
            double imag = x.imaginaryPart + y.imaginaryPart;
            Complex result = new Complex(real,imag);
            return result;
        }
        public static Complex Subtract(Complex x,Complex y)
        {
            double real = x.realPart - y.realPart;
            double imag = x.imaginaryPart - y.imaginaryPart;
            Complex result = new Complex(real, imag);
            return result;
        }
        public static Complex operator +(Complex x,Complex y)
        {
            return Addnum(x,y);
        }

        public static Complex operator -(Complex x,Complex y)
        {  
            return Addnum(x,y);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Complex a = new Complex(1, 2);
            Complex b = new Complex(3, 4);
            Complex addition = new Complex();
           

            Console.WriteLine("{0}+{1}i",addition.RealPart,addition.ImaginaryPart);

        }
    }
}
