﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Asset
    {
        public string Name { get; set; }
        private decimal value;
        private decimal depreciationRate;
        public decimal Value
        {
            set
            {
                if (value > 0)
                {
                    this.value = value;
                }

            }
            get
            {
                return this.value;
            }
        }
        public decimal DepreciationRate
        {
            set
            {
                if (value > 0)
                {
                    depreciationRate = value;
                }
            }
            get
            {
                return depreciationRate;
            }
        }
        public Asset() { }
        public Asset(string x, decimal AssetVal, decimal DepRate)
        {
            Name = x;
            Value = AssetVal;
            DepreciationRate = DepRate;
        }

        public void AssetTest()
        {
            Console.WriteLine("Asset Name :{0:C}\nAsset value:{1:C}\nasst deprate{2:C}", Name, Value, DepreciationRate);
            Value = Value + (Value * 0.05M);
            Console.WriteLine("new value: {0:C}", Value);


        }
    }
        internal class Program
        {
            static void Main(string[] args)
            {
                Asset a = new Asset("farah", 68.0M, 99.0M);
                Asset a2 = new Asset("yousef", 69.0M, 97.0M);
                a.AssetTest();
                a2.AssetTest();
            }
        }
    
}
