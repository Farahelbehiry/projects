﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        class Vehicle
        {
            public virtual void TypeVehicle()
            {
                Console.WriteLine("Vehicle...");
            }

            public void type()
            {
                Console.WriteLine("Vehicle...");
            }
        }

        class Car : Vehicle
        {
            public override void TypeVehicle()
            {
                Console.WriteLine("Car...");
            }

            public void type()
            {
                Console.WriteLine("Car...");
            }

            public void MyColor()
            {
                Console.WriteLine("My Color is Blue.");
            }
        }

        class Bus : Vehicle
        {
            public override void TypeVehicle()
            {
                Console.WriteLine("Bus...");
            }

            public void type()
            {
                Console.WriteLine("Bus...");
            }

            public void PrintPassengerNumber()
            {
                Console.WriteLine("My Passengers number is 40.");
            }
        }
            static void Main(string[] args)
        {
            Vehicle[] vehicles = new Vehicle[3];
            vehicles[0] = new Vehicle();
            vehicles[1] = new Car();
            vehicles[2] = new Bus();

            foreach (var vehicle in vehicles)
            {
                vehicle.TypeVehicle();
                vehicle.type();

                if (vehicle is Car)
                {
                    Car car = (Car)vehicle;
                    car.MyColor();
                }
                else if (vehicle is Bus)
                {
                    Bus bus = (Bus)vehicle;
                    bus.PrintPassengerNumber();
                }

                Console.WriteLine();
            }
        }
    }
    }

