﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    class A
    {
        public virtual decimal m1()
        {
            return 10.00m ;
        }
    }

    class B:A 
    { 
        public override decimal m1 ()
        {
            
            return base.m1()+2;
           
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            A a = new A();
            Console.WriteLine($"price is :{((B)a).m1()}");
        }
    }
}
