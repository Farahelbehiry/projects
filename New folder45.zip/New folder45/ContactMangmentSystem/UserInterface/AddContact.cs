﻿using ContactManagementSystem;
using System;
using System.Windows.Forms;

namespace UserInterface
{
    public partial class AddContact : Form
    {


        public Contact NewContact { get; private set; }
        private readonly ContactDataAccess contactDataAccess = new ContactDataAccess();
        private readonly Contact existingContact;

        public AddContact()
        {
            InitializeComponent();
        }

        private void AddDetailesButton_Click(object sender, EventArgs e)
        {
            string Namee = NameTextBox.Text;
            string Phone = PhoneNumberTextBox.Text;

            AddDetailes form2 = new AddDetailes(this, Namee, Phone);
            form2.ShowDialog();
        }

        public void Savebutton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text) || string.IsNullOrEmpty(PhoneNumberTextBox.Text))
            {
                MessageBox.Show("Name and Phone Number are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (existingContact == null)
            {
                Contact newContact = new SimpleContact(NameTextBox.Text, PhoneNumberTextBox.Text);
                contactDataAccess.AddContact(newContact);

                NewContact = newContact;


                MessageBox.Show("Contact added successfully.");


                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show("Contact is already Exist.");
            }

            Close();

        }



        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddContact_Load(object sender, EventArgs e)
        {
           
        }

    }
}