﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ContactManagementSystem;

namespace UserInterface
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
            try
            {
                this.contactTablTableAdapter.Fill(this.contactSystemDBDataSet2.ContactTabl);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        readonly string conn = "Data Source=DESKTOP-HPGI7KC;Initial Catalog=ContactSystemDB;Integrated Security=True;";


        private void DeleteForm_Load(object sender, EventArgs e)
        {


                
                dataGridViewContact.AllowUserToAddRows = false;
                DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
                dataGridViewContact.Columns.Insert(0, buttonColumn);
                buttonColumn.HeaderText = "Delete";
                buttonColumn.Width = 100;
                buttonColumn.Text = "Delete";
                buttonColumn.UseColumnTextForButtonValue = true;
                

        }

        private void Ab(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewContact.Rows[e.RowIndex];
                if (MessageBox.Show("Do You Want To Delete This row?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(conn))
                    {
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM ContactTabl WHERE PhoneNumber = @PhoneNumber", connection))
                        {
                            cmd.Parameters.AddWithValue("@PhoneNumber", row.Cells["phoneNumberDataGridViewTextBoxColumn"].Value);
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                    this.contactTablTableAdapter.Fill(this.contactSystemDBDataSet2.ContactTabl);
                }
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            Close();
        }


    }
}
