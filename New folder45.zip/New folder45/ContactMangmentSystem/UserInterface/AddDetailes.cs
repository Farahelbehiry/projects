﻿using ContactManagementSystem;
using System;
using System.Windows.Forms;

namespace UserInterface
{
    public partial class AddDetailes : Form
    {
        readonly string name;
        readonly string phone;
        readonly string f;
        readonly string u;
        private readonly AddContact A = new AddContact();
        private readonly DetailedContact detailedContact;
        private readonly ContactDataAccess contactDataAccess;
        private readonly AddContact callingForm;

        public AddDetailes(string x, string u)
        {
            InitializeComponent();
            f = x;
            this.u = u;
            
        }

        
        public AddDetailes(AddContact callingForm, string Namee, string Phone)
        {
            InitializeComponent();
            this.callingForm = callingForm;
            name = Namee;
            phone = Phone;


            detailedContact = new DetailedContact("", "", new ContactGroup(), "", "", new Address(), 0, "", "", "", "", "");

            contactDataAccess = new ContactDataAccess();
        }

        private void Cancelbutton1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Savebutton1_Click(object sender, EventArgs e)
        {

            try
            {
                callingForm.Savebutton_Click(sender, e);

                DetailedContact updatedContact = new DetailedContact(name, phone, new ContactGroup(f,u), FullNameTextBox.Text, EmailAddressTextBox.Text,

                    new Address(StreetTextBox.Text, CityTextBox.Text,int.TryParse(PostalCodeTextBox.Text, out int postalCode) ? postalCode : 0,CountryTextBox.Text),

                    int.TryParse(AgeTextBox.Text, out int age) ? age : 0,GenderComboBox.Text,FaceBookTextBox.Text, WorkSpaceTextBox.Text,NickNameTextBox.Text, OtherNumberTextBox.Text);

                contactDataAccess.AddDetailedContact(updatedContact);

                MessageBox.Show("Successfully saved");
               
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}