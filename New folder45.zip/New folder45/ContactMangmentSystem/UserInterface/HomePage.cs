﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ContactManagementSystem;

namespace UserInterface
{

    public partial class HomePage : Form
    {


        public HomePage()
        {
            InitializeComponent();
        }

        private void AddNewContactButton_Click(object sender, EventArgs e)
        {

            new AddContact().Show();

        }

        private void DeleteContactButton_Click(object sender, EventArgs e)
        {
            new DeleteForm().Show();
        }

        private void GroupsButton_Click(object sender, EventArgs e)
        {
           new AddGroup().Show();   
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Searchbutton_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
                using (DataTable dt = new DataTable("ContactTabl"))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM ContactTabl WHERE Name LIKE @Name OR PhoneNumber LIKE @PhoneNumber", connection))
                    {
                        cmd.Parameters.AddWithValue("@Name", $"%{SearchTextBox.Text}%");
                        cmd.Parameters.AddWithValue("@PhoneNumber", $"%{SearchTextBox.Text}%");
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(dt);
                        dataGridView.DataSource = dt;
                        lblTotal.Text = $"Total records: {dataGridView.RowCount}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void SearchTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                Searchbutton_Click(sender, e);
        }
        public void RefreshGroupData()
        {
            using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
            using (DataTable dt = new DataTable("GroupTab"))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM GroupTab", connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(dt);
                    dataGridView.DataSource = dt;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
                using (DataTable dt = new DataTable("ContactTabl"))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM ContactTabl", connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(dt);
                        dataGridView.DataSource = dt;
                        lblTotal.Text = $"Total records: {dataGridView.RowCount}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HomePage_Load(object sender, EventArgs e)
        {

        }
    }
}

