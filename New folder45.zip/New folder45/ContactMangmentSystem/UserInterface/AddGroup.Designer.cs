﻿namespace UserInterface
{
    partial class AddGroup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddGroup));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupTabBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contactSystemDBDataSet3 = new UserInterface.ContactSystemDBDataSet3();
            this.groupTabTableAdapter = new UserInterface.ContactSystemDBDataSet3TableAdapters.GroupTabTableAdapter();
            this.AddNewGrouplabel = new System.Windows.Forms.Label();
            this.AddGroupButton = new System.Windows.Forms.Button();
            this.Descriptionlabel = new System.Windows.Forms.Label();
            this.DiscriptionTextBox = new System.Windows.Forms.TextBox();
            this.GroupNamelabel = new System.Windows.Forms.Label();
            this.GroupNameTextBox = new System.Windows.Forms.TextBox();
            this.Returnbutton2 = new System.Windows.Forms.Button();
            this.PhoneNumbercomboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupTabBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactSystemDBDataSet3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.groupNameDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.groupDescriptionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.groupTabBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(23, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(714, 974);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupNameDataGridViewTextBoxColumn
            // 
            this.groupNameDataGridViewTextBoxColumn.DataPropertyName = "GroupName";
            this.groupNameDataGridViewTextBoxColumn.HeaderText = "GroupName";
            this.groupNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.groupNameDataGridViewTextBoxColumn.Name = "groupNameDataGridViewTextBoxColumn";
            this.groupNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "PhoneNumber";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "PhoneNumber";
            this.phoneNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            this.phoneNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // groupDescriptionDataGridViewTextBoxColumn
            // 
            this.groupDescriptionDataGridViewTextBoxColumn.DataPropertyName = "GroupDescription";
            this.groupDescriptionDataGridViewTextBoxColumn.HeaderText = "GroupDescription";
            this.groupDescriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.groupDescriptionDataGridViewTextBoxColumn.Name = "groupDescriptionDataGridViewTextBoxColumn";
            this.groupDescriptionDataGridViewTextBoxColumn.Width = 125;
            // 
            // groupTabBindingSource
            // 
            this.groupTabBindingSource.DataMember = "GroupTab";
            this.groupTabBindingSource.DataSource = this.contactSystemDBDataSet3;
            // 
            // contactSystemDBDataSet3
            // 
            this.contactSystemDBDataSet3.DataSetName = "ContactSystemDBDataSet3";
            this.contactSystemDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupTabTableAdapter
            // 
            this.groupTabTableAdapter.ClearBeforeFill = true;
            // 
            // AddNewGrouplabel
            // 
            this.AddNewGrouplabel.AutoSize = true;
            this.AddNewGrouplabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.AddNewGrouplabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewGrouplabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.AddNewGrouplabel.Location = new System.Drawing.Point(1266, 38);
            this.AddNewGrouplabel.Name = "AddNewGrouplabel";
            this.AddNewGrouplabel.Size = new System.Drawing.Size(603, 91);
            this.AddNewGrouplabel.TabIndex = 18;
            this.AddNewGrouplabel.Text = "Add New Group";
            // 
            // AddGroupButton
            // 
            this.AddGroupButton.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddGroupButton.Location = new System.Drawing.Point(1230, 801);
            this.AddGroupButton.Name = "AddGroupButton";
            this.AddGroupButton.Size = new System.Drawing.Size(259, 100);
            this.AddGroupButton.TabIndex = 17;
            this.AddGroupButton.Text = "Add Group";
            this.AddGroupButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.AddGroupButton.UseVisualStyleBackColor = true;
            this.AddGroupButton.Click += new System.EventHandler(this.AddGroupButton_Click);
            // 
            // Descriptionlabel
            // 
            this.Descriptionlabel.AutoSize = true;
            this.Descriptionlabel.BackColor = System.Drawing.Color.Transparent;
            this.Descriptionlabel.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Descriptionlabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.Descriptionlabel.Location = new System.Drawing.Point(1210, 559);
            this.Descriptionlabel.Name = "Descriptionlabel";
            this.Descriptionlabel.Size = new System.Drawing.Size(278, 71);
            this.Descriptionlabel.TabIndex = 14;
            this.Descriptionlabel.Text = "Description :";
            // 
            // DiscriptionTextBox
            // 
            this.DiscriptionTextBox.Location = new System.Drawing.Point(1538, 595);
            this.DiscriptionTextBox.Name = "DiscriptionTextBox";
            this.DiscriptionTextBox.Size = new System.Drawing.Size(331, 22);
            this.DiscriptionTextBox.TabIndex = 13;
            // 
            // GroupNamelabel
            // 
            this.GroupNamelabel.AutoSize = true;
            this.GroupNamelabel.BackColor = System.Drawing.Color.Transparent;
            this.GroupNamelabel.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupNamelabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.GroupNamelabel.Location = new System.Drawing.Point(1210, 488);
            this.GroupNamelabel.Name = "GroupNamelabel";
            this.GroupNamelabel.Size = new System.Drawing.Size(279, 71);
            this.GroupNamelabel.TabIndex = 12;
            this.GroupNamelabel.Text = "GroupName :";
            // 
            // GroupNameTextBox
            // 
            this.GroupNameTextBox.Location = new System.Drawing.Point(1538, 521);
            this.GroupNameTextBox.Name = "GroupNameTextBox";
            this.GroupNameTextBox.Size = new System.Drawing.Size(331, 22);
            this.GroupNameTextBox.TabIndex = 11;
            // 
            // Returnbutton2
            // 
            this.Returnbutton2.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton2.Location = new System.Drawing.Point(1746, 801);
            this.Returnbutton2.Name = "Returnbutton2";
            this.Returnbutton2.Size = new System.Drawing.Size(259, 100);
            this.Returnbutton2.TabIndex = 19;
            this.Returnbutton2.Text = "Return";
            this.Returnbutton2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Returnbutton2.UseVisualStyleBackColor = true;
            this.Returnbutton2.Click += new System.EventHandler(this.Returnbutton2_Click);
            // 
            // PhoneNumbercomboBox
            // 
            this.PhoneNumbercomboBox.FormattingEnabled = true;
            this.PhoneNumbercomboBox.Location = new System.Drawing.Point(1349, 660);
            this.PhoneNumbercomboBox.Name = "PhoneNumbercomboBox";
            this.PhoneNumbercomboBox.Size = new System.Drawing.Size(407, 24);
            this.PhoneNumbercomboBox.TabIndex = 20;
            // 
            // AddGroup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1924, 913);
            this.Controls.Add(this.PhoneNumbercomboBox);
            this.Controls.Add(this.Returnbutton2);
            this.Controls.Add(this.AddNewGrouplabel);
            this.Controls.Add(this.AddGroupButton);
            this.Controls.Add(this.Descriptionlabel);
            this.Controls.Add(this.DiscriptionTextBox);
            this.Controls.Add(this.GroupNamelabel);
            this.Controls.Add(this.GroupNameTextBox);
            this.Controls.Add(this.dataGridView1);
            this.Name = "AddGroup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Group";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AddGroup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupTabBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactSystemDBDataSet3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private ContactSystemDBDataSet3 contactSystemDBDataSet3;
        private System.Windows.Forms.BindingSource groupTabBindingSource;
        private ContactSystemDBDataSet3TableAdapters.GroupTabTableAdapter groupTabTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn groupNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn groupDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label AddNewGrouplabel;
        private System.Windows.Forms.Button AddGroupButton;
        private System.Windows.Forms.Label Descriptionlabel;
        public System.Windows.Forms.TextBox DiscriptionTextBox;
        private System.Windows.Forms.Label GroupNamelabel;
        public System.Windows.Forms.TextBox GroupNameTextBox;
        private System.Windows.Forms.Button Returnbutton2;
        private System.Windows.Forms.ComboBox PhoneNumbercomboBox;
    }
}