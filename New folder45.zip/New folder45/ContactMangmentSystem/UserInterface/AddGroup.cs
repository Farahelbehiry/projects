﻿using ContactManagementSystem;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace UserInterface
{
    public partial class AddGroup : Form
    {
        public static string zeft;
        public static string zeft2;
        private static readonly AddDetailes addDetailes = new AddDetailes(zeft, zeft2);
        private readonly AddDetailes z = addDetailes;

        private readonly string conn = "Data Source=DESKTOP-HPGI7KC;Initial Catalog=ContactSystemDB;Integrated Security=True;";

        public AddGroup()
        {
            InitializeComponent();
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            
        }
        private void FillComboBox()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-HPGI7KC;Initial Catalog=ContactSystemDB;Integrated Security=True;");
            PhoneNumbercomboBox.Items.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select PhoneNumber from ContactTabl";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                PhoneNumbercomboBox.Items.Add(dr["PhoneNumber"].ToString());
            }
            con.Close();
        }
        private void AddGroup_Load(object sender, EventArgs e)
        {
            FillComboBox();

            try
            {

                this.groupTabTableAdapter.Fill(this.contactSystemDBDataSet3.GroupTab);


                dataGridView1.AllowUserToAddRows = false;


                DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
                dataGridView1.Columns.Insert(0, buttonColumn);
                buttonColumn.HeaderText = "Delete";
                buttonColumn.Width = 100;
                buttonColumn.Text = "Delete";
                buttonColumn.UseColumnTextForButtonValue = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0 && e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[e.RowIndex];


                    MessageBox.Show("Clicked on row with PhoneNumber: " + row.Cells["phoneNumberDataGridViewTextBoxColumn"].Value);

                    if (MessageBox.Show("Do You Want To Delete This row?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection(conn))
                        {
                            using (SqlCommand cmd = new SqlCommand("DELETE FROM GroupTab WHERE PhoneNumber = @PhoneNumber", connection))
                            {

                                try
                                {
                                    cmd.Parameters.AddWithValue("@PhoneNumber", row.Cells["phoneNumberDataGridViewTextBoxColumn"].Value);
                                    connection.Open();
                                    int rowsAffected = cmd.ExecuteNonQuery();

                                    if (rowsAffected > 0)
                                    {
                                        MessageBox.Show("Row deleted successfully.");
                                    }
                                    else
                                    {
                                        MessageBox.Show("No rows were deleted.");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error deleting row: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                finally
                                {
                                    connection.Close();
                                }
                            }
                        }


                        this.groupTabTableAdapter.Fill(this.contactSystemDBDataSet3.GroupTab);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error handling CellContentClick: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Returnbutton2_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void AddGroupButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
                using (SqlCommand cmd = new SqlCommand("INSERT INTO GroupTab (GroupName, PhoneNumber, GroupDescription) VALUES (@GroupName, @PhoneNumber, @GroupDescription); SELECT SCOPE_IDENTITY();", connection))
                {
                    zeft = GroupNameTextBox.Text;
                    zeft2 = DiscriptionTextBox.Text;
                    
                    cmd.Parameters.AddWithValue("@GroupName", GroupNameTextBox.Text);
                    cmd.Parameters.AddWithValue("@GroupDescription", DiscriptionTextBox.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNumbercomboBox.Text);
                    object result = cmd.ExecuteScalar();
                    MessageBox.Show($"Successfully saved.");


                }

                this.groupTabTableAdapter.Fill(this.contactSystemDBDataSet3.GroupTab);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



    }
}

