﻿namespace UserInterface
{
    partial class AddContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddContact));
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.Namelabel = new System.Windows.Forms.Label();
            this.PhoneNumberlabel = new System.Windows.Forms.Label();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.AddDetailesButton = new System.Windows.Forms.Button();
            this.Savebutton = new System.Windows.Forms.Button();
            this.AddNewContactlabel = new System.Windows.Forms.Label();
            this.contactTablBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.contactSystemDBDataSet = new UserInterface.ContactSystemDBDataSet();
            this.contactTablTableAdapter = new UserInterface.ContactSystemDBDataSetTableAdapters.ContactTablTableAdapter();
            this.Cancelbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.contactTablBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactSystemDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(959, 252);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(331, 22);
            this.NameTextBox.TabIndex = 0;
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.BackColor = System.Drawing.Color.Transparent;
            this.Namelabel.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Namelabel.Location = new System.Drawing.Point(765, 216);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(164, 71);
            this.Namelabel.TabIndex = 1;
            this.Namelabel.Text = "Name :";
            // 
            // PhoneNumberlabel
            // 
            this.PhoneNumberlabel.AutoSize = true;
            this.PhoneNumberlabel.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumberlabel.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumberlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.PhoneNumberlabel.Location = new System.Drawing.Point(613, 287);
            this.PhoneNumberlabel.Name = "PhoneNumberlabel";
            this.PhoneNumberlabel.Size = new System.Drawing.Size(316, 71);
            this.PhoneNumberlabel.TabIndex = 3;
            this.PhoneNumberlabel.Text = "PhoneNumber :";
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(959, 323);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(331, 22);
            this.PhoneNumberTextBox.TabIndex = 2;
            // 
            // AddDetailesButton
            // 
            this.AddDetailesButton.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDetailesButton.Location = new System.Drawing.Point(874, 482);
            this.AddDetailesButton.Name = "AddDetailesButton";
            this.AddDetailesButton.Size = new System.Drawing.Size(259, 100);
            this.AddDetailesButton.TabIndex = 6;
            this.AddDetailesButton.Text = "AddDetailes";
            this.AddDetailesButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.AddDetailesButton.UseVisualStyleBackColor = true;
            this.AddDetailesButton.Click += new System.EventHandler(this.AddDetailesButton_Click);
            // 
            // Savebutton
            // 
            this.Savebutton.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebutton.Location = new System.Drawing.Point(1487, 781);
            this.Savebutton.Name = "Savebutton";
            this.Savebutton.Size = new System.Drawing.Size(200, 100);
            this.Savebutton.TabIndex = 7;
            this.Savebutton.Text = "Save";
            this.Savebutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Savebutton.UseVisualStyleBackColor = true;
            this.Savebutton.Click += new System.EventHandler(this.Savebutton_Click);
            // 
            // AddNewContactlabel
            // 
            this.AddNewContactlabel.AutoSize = true;
            this.AddNewContactlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewContactlabel.Location = new System.Drawing.Point(676, 9);
            this.AddNewContactlabel.Name = "AddNewContactlabel";
            this.AddNewContactlabel.Size = new System.Drawing.Size(614, 91);
            this.AddNewContactlabel.TabIndex = 10;
            this.AddNewContactlabel.Text = "AddNewContact";
            // 
            // contactTablBindingSource
            // 
            this.contactTablBindingSource.DataMember = "ContactTabl";
            this.contactTablBindingSource.DataSource = this.contactSystemDBDataSet;
            // 
            // contactSystemDBDataSet
            // 
            this.contactSystemDBDataSet.DataSetName = "ContactSystemDBDataSet";
            this.contactSystemDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // contactTablTableAdapter
            // 
            this.contactTablTableAdapter.ClearBeforeFill = true;
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancelbutton.Location = new System.Drawing.Point(1781, 781);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(200, 100);
            this.Cancelbutton.TabIndex = 8;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // AddContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(2017, 913);
            this.Controls.Add(this.AddNewContactlabel);
            this.Controls.Add(this.Cancelbutton);
            this.Controls.Add(this.Savebutton);
            this.Controls.Add(this.AddDetailesButton);
            this.Controls.Add(this.PhoneNumberlabel);
            this.Controls.Add(this.PhoneNumberTextBox);
            this.Controls.Add(this.Namelabel);
            this.Controls.Add(this.NameTextBox);
            this.Name = "AddContact";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddContact";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AddContact_Load);
            ((System.ComponentModel.ISupportInitialize)(this.contactTablBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contactSystemDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.Label PhoneNumberlabel;
        private System.Windows.Forms.Button AddDetailesButton;
        private System.Windows.Forms.Button Savebutton;
        private System.Windows.Forms.Label AddNewContactlabel;
        private ContactSystemDBDataSet contactSystemDBDataSet;
        private System.Windows.Forms.BindingSource contactTablBindingSource;
        private ContactSystemDBDataSetTableAdapters.ContactTablTableAdapter contactTablTableAdapter;
        private System.Windows.Forms.Button Cancelbutton;
        public System.Windows.Forms.TextBox PhoneNumberTextBox;
        public System.Windows.Forms.TextBox NameTextBox;
    }
}