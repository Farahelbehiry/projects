﻿namespace UserInterface
{
    partial class AddDetailes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddDetailes));
            this.AddDetailesToContactlabel = new System.Windows.Forms.Label();
            this.Cancelbutton1 = new System.Windows.Forms.Button();
            this.Savebutton1 = new System.Windows.Forms.Button();
            this.NickNamelabel = new System.Windows.Forms.Label();
            this.NickNameTextBox = new System.Windows.Forms.TextBox();
            this.EmailAddresslabel = new System.Windows.Forms.Label();
            this.EmailAddressTextBox = new System.Windows.Forms.TextBox();
            this.FullNamelabel = new System.Windows.Forms.Label();
            this.FullNameTextBox = new System.Windows.Forms.TextBox();
            this.Facbooklabel = new System.Windows.Forms.Label();
            this.FaceBookTextBox = new System.Windows.Forms.TextBox();
            this.WorkSpacelabel = new System.Windows.Forms.Label();
            this.WorkSpaceTextBox = new System.Windows.Forms.TextBox();
            this.Countrylabel = new System.Windows.Forms.Label();
            this.CountryTextBox = new System.Windows.Forms.TextBox();
            this.Citylabel = new System.Windows.Forms.Label();
            this.CityTextBox = new System.Windows.Forms.TextBox();
            this.PostalCodelabel = new System.Windows.Forms.Label();
            this.PostalCodeTextBox = new System.Windows.Forms.TextBox();
            this.Streetlabel = new System.Windows.Forms.Label();
            this.StreetTextBox = new System.Windows.Forms.TextBox();
            this.Genderlabel = new System.Windows.Forms.Label();
            this.Agelabel = new System.Windows.Forms.Label();
            this.AgeTextBox = new System.Windows.Forms.TextBox();
            this.OtherNumberlabel = new System.Windows.Forms.Label();
            this.OtherNumberTextBox = new System.Windows.Forms.TextBox();
            this.GenderComboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // AddDetailesToContactlabel
            // 
            this.AddDetailesToContactlabel.AutoSize = true;
            this.AddDetailesToContactlabel.BackColor = System.Drawing.Color.Transparent;
            this.AddDetailesToContactlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDetailesToContactlabel.ForeColor = System.Drawing.Color.Chartreuse;
            this.AddDetailesToContactlabel.Location = new System.Drawing.Point(592, 9);
            this.AddDetailesToContactlabel.Name = "AddDetailesToContactlabel";
            this.AddDetailesToContactlabel.Size = new System.Drawing.Size(833, 91);
            this.AddDetailesToContactlabel.TabIndex = 20;
            this.AddDetailesToContactlabel.Text = "AddDetailesToContact";
            // 
            // Cancelbutton1
            // 
            this.Cancelbutton1.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancelbutton1.ForeColor = System.Drawing.Color.Chocolate;
            this.Cancelbutton1.Location = new System.Drawing.Point(1712, 777);
            this.Cancelbutton1.Name = "Cancelbutton1";
            this.Cancelbutton1.Size = new System.Drawing.Size(200, 100);
            this.Cancelbutton1.TabIndex = 19;
            this.Cancelbutton1.Text = "Cancel";
            this.Cancelbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Cancelbutton1.UseVisualStyleBackColor = true;
            this.Cancelbutton1.Click += new System.EventHandler(this.Cancelbutton1_Click);
            // 
            // Savebutton1
            // 
            this.Savebutton1.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebutton1.ForeColor = System.Drawing.Color.Chocolate;
            this.Savebutton1.Location = new System.Drawing.Point(1358, 777);
            this.Savebutton1.Name = "Savebutton1";
            this.Savebutton1.Size = new System.Drawing.Size(200, 100);
            this.Savebutton1.TabIndex = 18;
            this.Savebutton1.Text = "Save";
            this.Savebutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Savebutton1.UseVisualStyleBackColor = true;
            this.Savebutton1.Click += new System.EventHandler(this.Savebutton1_Click);
            // 
            // NickNamelabel
            // 
            this.NickNamelabel.AutoSize = true;
            this.NickNamelabel.BackColor = System.Drawing.Color.Transparent;
            this.NickNamelabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NickNamelabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NickNamelabel.Location = new System.Drawing.Point(201, 268);
            this.NickNamelabel.Name = "NickNamelabel";
            this.NickNamelabel.Size = new System.Drawing.Size(313, 62);
            this.NickNamelabel.TabIndex = 16;
            this.NickNamelabel.Text = "NickName :";
            // 
            // NickNameTextBox
            // 
            this.NickNameTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.NickNameTextBox.Location = new System.Drawing.Point(524, 301);
            this.NickNameTextBox.Name = "NickNameTextBox";
            this.NickNameTextBox.Size = new System.Drawing.Size(331, 22);
            this.NickNameTextBox.TabIndex = 15;
            this.NickNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EmailAddresslabel
            // 
            this.EmailAddresslabel.AutoSize = true;
            this.EmailAddresslabel.BackColor = System.Drawing.Color.Transparent;
            this.EmailAddresslabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailAddresslabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EmailAddresslabel.Location = new System.Drawing.Point(102, 197);
            this.EmailAddresslabel.Name = "EmailAddresslabel";
            this.EmailAddresslabel.Size = new System.Drawing.Size(416, 62);
            this.EmailAddresslabel.TabIndex = 14;
            this.EmailAddresslabel.Text = "Email Address :";
            // 
            // EmailAddressTextBox
            // 
            this.EmailAddressTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.EmailAddressTextBox.Location = new System.Drawing.Point(524, 230);
            this.EmailAddressTextBox.Name = "EmailAddressTextBox";
            this.EmailAddressTextBox.Size = new System.Drawing.Size(331, 22);
            this.EmailAddressTextBox.TabIndex = 13;
            this.EmailAddressTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FullNamelabel
            // 
            this.FullNamelabel.AutoSize = true;
            this.FullNamelabel.BackColor = System.Drawing.Color.Transparent;
            this.FullNamelabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FullNamelabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FullNamelabel.Location = new System.Drawing.Point(201, 126);
            this.FullNamelabel.Name = "FullNamelabel";
            this.FullNamelabel.Size = new System.Drawing.Size(317, 62);
            this.FullNamelabel.TabIndex = 12;
            this.FullNamelabel.Text = "Full Name :";
            // 
            // FullNameTextBox
            // 
            this.FullNameTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.FullNameTextBox.Location = new System.Drawing.Point(524, 159);
            this.FullNameTextBox.Name = "FullNameTextBox";
            this.FullNameTextBox.Size = new System.Drawing.Size(331, 22);
            this.FullNameTextBox.TabIndex = 11;
            this.FullNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Facbooklabel
            // 
            this.Facbooklabel.AutoSize = true;
            this.Facbooklabel.BackColor = System.Drawing.Color.Transparent;
            this.Facbooklabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Facbooklabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Facbooklabel.Location = new System.Drawing.Point(231, 420);
            this.Facbooklabel.Name = "Facbooklabel";
            this.Facbooklabel.Size = new System.Drawing.Size(283, 62);
            this.Facbooklabel.TabIndex = 26;
            this.Facbooklabel.Text = "Facebook :";
            // 
            // FaceBookTextBox
            // 
            this.FaceBookTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.FaceBookTextBox.Location = new System.Drawing.Point(524, 453);
            this.FaceBookTextBox.Name = "FaceBookTextBox";
            this.FaceBookTextBox.Size = new System.Drawing.Size(331, 22);
            this.FaceBookTextBox.TabIndex = 25;
            this.FaceBookTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // WorkSpacelabel
            // 
            this.WorkSpacelabel.AutoSize = true;
            this.WorkSpacelabel.BackColor = System.Drawing.Color.Transparent;
            this.WorkSpacelabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkSpacelabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.WorkSpacelabel.Location = new System.Drawing.Point(184, 346);
            this.WorkSpacelabel.Name = "WorkSpacelabel";
            this.WorkSpacelabel.Size = new System.Drawing.Size(334, 62);
            this.WorkSpacelabel.TabIndex = 24;
            this.WorkSpacelabel.Text = "WorkSpace :";
            // 
            // WorkSpaceTextBox
            // 
            this.WorkSpaceTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.WorkSpaceTextBox.Location = new System.Drawing.Point(524, 382);
            this.WorkSpaceTextBox.Name = "WorkSpaceTextBox";
            this.WorkSpaceTextBox.Size = new System.Drawing.Size(331, 22);
            this.WorkSpaceTextBox.TabIndex = 23;
            this.WorkSpaceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Countrylabel
            // 
            this.Countrylabel.AutoSize = true;
            this.Countrylabel.BackColor = System.Drawing.Color.Transparent;
            this.Countrylabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Countrylabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Countrylabel.Location = new System.Drawing.Point(1177, 446);
            this.Countrylabel.Name = "Countrylabel";
            this.Countrylabel.Size = new System.Drawing.Size(249, 62);
            this.Countrylabel.TabIndex = 36;
            this.Countrylabel.Text = "Country :";
            // 
            // CountryTextBox
            // 
            this.CountryTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.CountryTextBox.Location = new System.Drawing.Point(1456, 479);
            this.CountryTextBox.Name = "CountryTextBox";
            this.CountryTextBox.Size = new System.Drawing.Size(331, 22);
            this.CountryTextBox.TabIndex = 35;
            this.CountryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Citylabel
            // 
            this.Citylabel.AutoSize = true;
            this.Citylabel.BackColor = System.Drawing.Color.Transparent;
            this.Citylabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Citylabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Citylabel.Location = new System.Drawing.Point(1272, 382);
            this.Citylabel.Name = "Citylabel";
            this.Citylabel.Size = new System.Drawing.Size(154, 62);
            this.Citylabel.TabIndex = 34;
            this.Citylabel.Text = "City :";
            // 
            // CityTextBox
            // 
            this.CityTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.CityTextBox.Location = new System.Drawing.Point(1456, 408);
            this.CityTextBox.Name = "CityTextBox";
            this.CityTextBox.Size = new System.Drawing.Size(331, 22);
            this.CityTextBox.TabIndex = 33;
            this.CityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PostalCodelabel
            // 
            this.PostalCodelabel.AutoSize = true;
            this.PostalCodelabel.BackColor = System.Drawing.Color.Transparent;
            this.PostalCodelabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalCodelabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PostalCodelabel.Location = new System.Drawing.Point(1087, 315);
            this.PostalCodelabel.Name = "PostalCodelabel";
            this.PostalCodelabel.Size = new System.Drawing.Size(338, 62);
            this.PostalCodelabel.TabIndex = 32;
            this.PostalCodelabel.Text = "Postal Code :";
            // 
            // PostalCodeTextBox
            // 
            this.PostalCodeTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.PostalCodeTextBox.Location = new System.Drawing.Point(1456, 337);
            this.PostalCodeTextBox.Name = "PostalCodeTextBox";
            this.PostalCodeTextBox.Size = new System.Drawing.Size(331, 22);
            this.PostalCodeTextBox.TabIndex = 31;
            this.PostalCodeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Streetlabel
            // 
            this.Streetlabel.AutoSize = true;
            this.Streetlabel.BackColor = System.Drawing.Color.Transparent;
            this.Streetlabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Streetlabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Streetlabel.Location = new System.Drawing.Point(1227, 244);
            this.Streetlabel.Name = "Streetlabel";
            this.Streetlabel.Size = new System.Drawing.Size(198, 62);
            this.Streetlabel.TabIndex = 30;
            this.Streetlabel.Text = "Street :";
            // 
            // StreetTextBox
            // 
            this.StreetTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.StreetTextBox.Location = new System.Drawing.Point(1456, 266);
            this.StreetTextBox.Name = "StreetTextBox";
            this.StreetTextBox.Size = new System.Drawing.Size(331, 22);
            this.StreetTextBox.TabIndex = 29;
            this.StreetTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Genderlabel
            // 
            this.Genderlabel.AutoSize = true;
            this.Genderlabel.BackColor = System.Drawing.Color.Transparent;
            this.Genderlabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Genderlabel.Location = new System.Drawing.Point(288, 562);
            this.Genderlabel.Name = "Genderlabel";
            this.Genderlabel.Size = new System.Drawing.Size(230, 62);
            this.Genderlabel.TabIndex = 28;
            this.Genderlabel.Text = "Gender :";
            // 
            // Agelabel
            // 
            this.Agelabel.AutoSize = true;
            this.Agelabel.BackColor = System.Drawing.Color.Transparent;
            this.Agelabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agelabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Agelabel.Location = new System.Drawing.Point(1275, 173);
            this.Agelabel.Name = "Agelabel";
            this.Agelabel.Size = new System.Drawing.Size(147, 62);
            this.Agelabel.TabIndex = 42;
            this.Agelabel.Text = "Age :";
            // 
            // AgeTextBox
            // 
            this.AgeTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.AgeTextBox.Location = new System.Drawing.Point(1455, 197);
            this.AgeTextBox.Name = "AgeTextBox";
            this.AgeTextBox.Size = new System.Drawing.Size(331, 22);
            this.AgeTextBox.TabIndex = 41;
            this.AgeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OtherNumberlabel
            // 
            this.OtherNumberlabel.AutoSize = true;
            this.OtherNumberlabel.BackColor = System.Drawing.Color.Transparent;
            this.OtherNumberlabel.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OtherNumberlabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.OtherNumberlabel.Location = new System.Drawing.Point(114, 491);
            this.OtherNumberlabel.Name = "OtherNumberlabel";
            this.OtherNumberlabel.Size = new System.Drawing.Size(404, 62);
            this.OtherNumberlabel.TabIndex = 40;
            this.OtherNumberlabel.Text = "Other Number :";
            // 
            // OtherNumberTextBox
            // 
            this.OtherNumberTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.OtherNumberTextBox.Location = new System.Drawing.Point(524, 524);
            this.OtherNumberTextBox.Name = "OtherNumberTextBox";
            this.OtherNumberTextBox.Size = new System.Drawing.Size(331, 22);
            this.OtherNumberTextBox.TabIndex = 39;
            this.OtherNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GenderComboBox
            // 
            this.GenderComboBox.BackColor = System.Drawing.Color.White;
            this.GenderComboBox.FormattingEnabled = true;
            this.GenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.GenderComboBox.Location = new System.Drawing.Point(524, 589);
            this.GenderComboBox.Name = "GenderComboBox";
            this.GenderComboBox.Size = new System.Drawing.Size(331, 24);
            this.GenderComboBox.TabIndex = 43;
            this.GenderComboBox.Text = "Choose a gender";
            // 
            // AddDetailes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(2017, 913);
            this.Controls.Add(this.GenderComboBox);
            this.Controls.Add(this.Agelabel);
            this.Controls.Add(this.AgeTextBox);
            this.Controls.Add(this.OtherNumberlabel);
            this.Controls.Add(this.OtherNumberTextBox);
            this.Controls.Add(this.Countrylabel);
            this.Controls.Add(this.CountryTextBox);
            this.Controls.Add(this.Citylabel);
            this.Controls.Add(this.CityTextBox);
            this.Controls.Add(this.PostalCodelabel);
            this.Controls.Add(this.PostalCodeTextBox);
            this.Controls.Add(this.Streetlabel);
            this.Controls.Add(this.StreetTextBox);
            this.Controls.Add(this.Genderlabel);
            this.Controls.Add(this.Facbooklabel);
            this.Controls.Add(this.FaceBookTextBox);
            this.Controls.Add(this.WorkSpacelabel);
            this.Controls.Add(this.WorkSpaceTextBox);
            this.Controls.Add(this.AddDetailesToContactlabel);
            this.Controls.Add(this.Cancelbutton1);
            this.Controls.Add(this.Savebutton1);
            this.Controls.Add(this.NickNamelabel);
            this.Controls.Add(this.NickNameTextBox);
            this.Controls.Add(this.EmailAddresslabel);
            this.Controls.Add(this.EmailAddressTextBox);
            this.Controls.Add(this.FullNamelabel);
            this.Controls.Add(this.FullNameTextBox);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddDetailes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Detailes";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AddDetailesToContactlabel;
        private System.Windows.Forms.Button Cancelbutton1;
        private System.Windows.Forms.Button Savebutton1;
        private System.Windows.Forms.Label NickNamelabel;
        private System.Windows.Forms.TextBox NickNameTextBox;
        private System.Windows.Forms.Label EmailAddresslabel;
        private System.Windows.Forms.TextBox EmailAddressTextBox;
        private System.Windows.Forms.Label FullNamelabel;
        private System.Windows.Forms.TextBox FullNameTextBox;
        private System.Windows.Forms.Label Facbooklabel;
        private System.Windows.Forms.TextBox FaceBookTextBox;
        private System.Windows.Forms.Label WorkSpacelabel;
        private System.Windows.Forms.TextBox WorkSpaceTextBox;
        private System.Windows.Forms.Label Countrylabel;
        private System.Windows.Forms.TextBox CountryTextBox;
        private System.Windows.Forms.Label Citylabel;
        private System.Windows.Forms.TextBox CityTextBox;
        private System.Windows.Forms.Label PostalCodelabel;
        private System.Windows.Forms.TextBox PostalCodeTextBox;
        private System.Windows.Forms.Label Streetlabel;
        private System.Windows.Forms.TextBox StreetTextBox;
        private System.Windows.Forms.Label Genderlabel;
        private System.Windows.Forms.Label Agelabel;
        private System.Windows.Forms.TextBox AgeTextBox;
        private System.Windows.Forms.Label OtherNumberlabel;
        private System.Windows.Forms.TextBox OtherNumberTextBox;
        private System.Windows.Forms.ComboBox GenderComboBox;
    }
}