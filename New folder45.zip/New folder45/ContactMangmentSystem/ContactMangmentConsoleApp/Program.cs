﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;



namespace ContactManagementSystem
{
    public abstract class Contact
    {
        public string Name;
        public string PhoneNumber;
        

        public Contact() { }
        public Contact(string name, string phoneNumber)
        {
            Name = name;
            PhoneNumber = phoneNumber;
        }

        public abstract void AddNewContact();
        public abstract void DisplayContact();
        public abstract void DeleteContact();
        public abstract void ModifyContact();
    }

    public class SimpleContact : Contact
    {


        public SimpleContact(string name, string phoneNumber) : base(name, phoneNumber)
        {

        }

        public override void AddNewContact()
        {
            Console.WriteLine("Enter new contact details:");

            Console.Write("Name: ");
            Name = Console.ReadLine();

            Console.Write("Phone Number: ");
            PhoneNumber = Console.ReadLine();

            Console.WriteLine("Simplecontact added successfully.");
        }

        public override void DisplayContact()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Phone Number: {PhoneNumber}");
            
        }

        public override void DeleteContact()
        {
            Console.WriteLine($"Deleting contact: {Name}");
            Name = null;
            PhoneNumber = null;
            Console.WriteLine("Contact deleted successfully.");
        }

        public override void ModifyContact()
        {
            Console.WriteLine($"Modifying contact: {Name}");

            Console.Write("Enter new name (Keep it empty to keep current): ");
            string newName = Console.ReadLine();
            if (!string.IsNullOrEmpty(newName))
            {
                Name = newName;
            }

            Console.Write("Enter new phone number (Keep it empty to keep current): ");
            string newPhoneNumberStr = Console.ReadLine();
            if (!string.IsNullOrEmpty(newPhoneNumberStr))
            {
                PhoneNumber = newPhoneNumberStr;

            }

            Console.WriteLine("Contact modified successfully.");
        }
    }

    public class DetailedContact : Contact
    {
        public string FullName;
        public string EmailAddress;
        public Address Address;
        public int Age;
        public string Gender;
        public string Facebook;
        public string WorkSpace;
        public string NickName;
        public string OtherNumber;
        public ContactGroup Group;

        public DetailedContact(
            string name, string phoneNumber, ContactGroup group, string fullName, string emailAddress, Address address,
            int age, string gender, string facebook, string workSpace, string nickName, string otherNumber)
            : base(name, phoneNumber)
        {
            FullName = fullName;
            EmailAddress = emailAddress;
            Address = address;
            Age = age;
            Gender = gender;
            Facebook = facebook;
            WorkSpace = workSpace;
            NickName = nickName;
            OtherNumber = otherNumber;
            Group = group;
        }

        public override void AddNewContact()
        {
            Console.WriteLine("Enter new detailedcontact details:");

            Console.Write("Full Name: ");
            FullName = Console.ReadLine();

            Console.Write("Email Address: ");
            EmailAddress = Console.ReadLine();

            Console.Write("Age: ");
            int.TryParse(Console.ReadLine(), out int age);
            Age = age;

            Console.Write("Gender: ");
            Gender = Console.ReadLine();

            Console.Write("Facebook: ");
            Facebook = Console.ReadLine();

            Console.Write("Workspace: ");
            WorkSpace = Console.ReadLine();

            Console.Write("Nickname: ");
            NickName = Console.ReadLine();

            Console.Write("Other Number: ");
            OtherNumber = Console.ReadLine();

            Console.WriteLine("Detailedcontact added successfully.");
        }

        public override void DisplayContact()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Phone Number: {PhoneNumber}");
            Console.WriteLine($"Group: {Group.GroupName}");
            Console.WriteLine($"Full Name: {FullName}");
            Console.WriteLine($"Email Address: {EmailAddress}");
            Console.WriteLine($"Age: {Age}");
            Console.WriteLine($"Gender: {Gender}");
            Console.WriteLine($"Facebook: {Facebook}");
            Console.WriteLine($"Workspace: {WorkSpace}");
            Console.WriteLine($"Nickname: {NickName}");
            Console.WriteLine($"OtherNumber: {OtherNumber}");
        }

        public override void DeleteContact()
        {
            Console.WriteLine($"Deleting detailedcontact: {Name}");
            Name = null;
            PhoneNumber = null;
            FullName = null;
            EmailAddress = null;
            Age = 0;
            Gender = null;
            Facebook = null;
            WorkSpace = null;
            NickName = null;
            OtherNumber = null;
            Console.WriteLine("Detailedcontact deleted successfully.");
        }

        public override void ModifyContact()
        {
            Console.WriteLine($"Modifying detailed contact: {Name}");

            Console.Write("Enter new name (Keep it empty to keep current): ");
            string newName = Console.ReadLine();
            if (!string.IsNullOrEmpty(newName))
            {
                Name = newName;
            }

            Console.Write("Enter new phone number (Keep it empty to keep current): ");
            string newPhoneNumberStr = Console.ReadLine();
            if (!string.IsNullOrEmpty(newPhoneNumberStr))
            {
                PhoneNumber = newPhoneNumberStr;

            }

            Console.Write("Enter new full name (Keep it empty to keep current): ");
            string newFullName = Console.ReadLine();
            if (!string.IsNullOrEmpty(newFullName))
            {
                FullName = newFullName;
            }

            Console.Write("Enter new email address (Keep it empty to keep current): ");
            string newEmailAddress = Console.ReadLine();
            if (!string.IsNullOrEmpty(newEmailAddress))
            {
                EmailAddress = newEmailAddress;
            }

            Console.Write("Enter new age (Keep it empty to keep current): ");
            string newAgeStr = Console.ReadLine();
            if (!string.IsNullOrEmpty(newAgeStr) && int.TryParse(newAgeStr, out int newAge))
            {
                Age = newAge;
            }

            Console.Write("Enter new gender (Keep it empty to keep current): ");
            string newGender = Console.ReadLine();
            if (!string.IsNullOrEmpty(newGender))
            {
                Gender = newGender;
            }

            Console.Write("Enter new Facebook (Keep it empty to keep current): ");
            string newFacebook = Console.ReadLine();
            if (!string.IsNullOrEmpty(newFacebook))
            {
                Facebook = newFacebook;
            }

            Console.Write("Enter new workspace (Keep it empty to keep current): ");
            string newWorkspace = Console.ReadLine();
            if (!string.IsNullOrEmpty(newWorkspace))
            {
                WorkSpace = newWorkspace;
            }

            Console.Write("Enter new nickname (Keep it empty to keep current): ");
            string newNickName = Console.ReadLine();
            if (!string.IsNullOrEmpty(newNickName))
            {
                NickName = newNickName;
            }

            Console.Write("Enter new other number (Keep it empty to keep current): ");
            string newOtherNumber = Console.ReadLine();
            if (!string.IsNullOrEmpty(newOtherNumber))
            {
                OtherNumber = newOtherNumber;
            }

            Console.WriteLine("Detailed contact modified successfully.");
        }

    }

    public class Address
    {
        public string Street;
        public string City;
        public int PostalCode;
        public string Country;

        public Address()
        {

        }

        public Address(string street, string city, int postalCode, string country)
        {
            Street = street;
            City = city;
            PostalCode = postalCode;
            Country = country;
        }

        public string GetAddress()
        {
            return $"{Street}, {City}, {PostalCode}, {Country}";
        }

        public void UpdatePostalCode(int newPostalCode)
        {
            PostalCode = newPostalCode;
        }

        public bool IsSameAddress(Address otherAddress)
        {
            return Street == otherAddress.Street &&
                   City == otherAddress.City &&
                   PostalCode == otherAddress.PostalCode &&
                   Country == otherAddress.Country;
        }
    }
    public class ContactGroup
    {
        public string GroupName;
        public string Description;
        public string PhoneNumber;
        public List<Contact> Contacts;

        public ContactGroup()
        {
            Contacts = new List<Contact>();
        }

        public ContactGroup(string groupName, string description) : this()
        {
            GroupName = groupName;
            Description = description;
        }

        public void AddContact(Contact contact)
        {
            Contacts.Add(contact);
        }

        public void RemoveContact(Contact contact)
        {
            Contacts.Remove(contact);
        }

        public void DisplayContacts()
        {
            Console.WriteLine($"Contacts in {GroupName} Group:");
            foreach (var contact in Contacts)
            {
                Console.WriteLine($"Name: {contact.Name}, Phone: {contact.PhoneNumber}");
            }
        }

        public void DeleteGroup()
        {
            Console.WriteLine($"Deleting group: {GroupName}");
            Contacts.Clear();
            Console.WriteLine("Group deleted successfully.");
        }
    }
    public class Validation
    {
        public void CheckDuplicateContacts(ContactGroup group)
        {
            List<Contact> contacts = group.Contacts;

            for (int i = 0; i < contacts.Count; i++)
            {
                for (int j = i + 1; j < contacts.Count; j++)
                {
                    if (contacts[i].PhoneNumber == contacts[j].PhoneNumber)
                    {
                        Console.WriteLine($"Duplicate phone number detected for contacts '{contacts[i].Name}' and '{contacts[j].Name}' in group '{group.GroupName}'.");
                        contacts.RemoveAt(j);
                        j--;
                    }
                }
            }
        }

        public void TransformContactType(List<Contact> contacts, Contact contactToTransform)
        {
            if (contactToTransform is SimpleContact)
            {
                TransformToDetailedContact(contacts, (SimpleContact)contactToTransform);
            }
            else if (contactToTransform is DetailedContact)
            {
                TransformToSimpleContact(contacts, (DetailedContact)contactToTransform);
            }
        }

        private void TransformToDetailedContact(List<Contact> contacts, SimpleContact simpleContact)
        {
            Console.WriteLine($"Transforming simple contact '{simpleContact.Name}' to detailed contact.");

            DetailedContact detailedContact = new DetailedContact(
                simpleContact.Name, simpleContact.PhoneNumber, new ContactGroup(),
                simpleContact.Name, string.Empty, new Address(), 0, string.Empty,
                string.Empty, string.Empty, string.Empty, string.Empty);

            contacts.Remove(simpleContact);

            contacts.Add(detailedContact);
        }

        private void TransformToSimpleContact(List<Contact> contacts, DetailedContact detailedContact)
        {
            Console.WriteLine($"Transforming detailed contact '{detailedContact.Name}' to simple contact.");

            SimpleContact simpleContact = new SimpleContact(
                detailedContact.Name,  detailedContact.PhoneNumber);

            contacts.Remove(detailedContact);

            contacts.Add(simpleContact);
        }

        public bool ValidateEmail(string email)
        {
            try
            {
                var mailAddress = new MailAddress(email);
                return true;
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid EmailAddress format.");
                Console.WriteLine("Invalid EmailAddress format.");
                return false;
            }
        }

        public bool ValidatePhoneNumber(string phoneNumber)
        {
            if (!string.IsNullOrEmpty(phoneNumber))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid phone number format.");
                return false;
            }
        }

        public bool ValidateAge(int age)
        {
            if (age >= 0 && age <= 150)
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid age value.");
                return false;
            }
        }

        public bool ValidateGroupName(string groupName)
        {
            if (!string.IsNullOrEmpty(groupName))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Group name cannot be empty.");
                return false;
            }
        }

        public bool ValidatePostalCode(int postalCode)
        {
            string postalCodeStr = postalCode.ToString();
            if (postalCodeStr.All(char.IsDigit) && postalCodeStr.Length == 5)
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid postal code format.");
                return false;
            }
        }
        public bool ValidateFullName(string fullName)
        {
            if (!string.IsNullOrEmpty(fullName))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Full name cannot be empty.");
                return false;
            }
        }
        public bool ValidateNickname(string nickname)
        {
            if (!string.IsNullOrEmpty(nickname) && nickname.Length <= 20)
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid nickname.");
                return false;
            }
        }

        public bool ValidateFacebookUsername(string facebookUsername)
        {
            if (Regex.IsMatch(facebookUsername, "^[a-zA-Z0-9]+$"))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid Facebook username format.");
                return false;
            }
        }

        public bool ValidateWorkspace(string workspace)
        {
            if (!string.IsNullOrEmpty(workspace))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Workspace name cannot be empty.");
                return false;
            }
        }

        public bool ValidateOtherNumber(string otherNumber)
        {
            if (!string.IsNullOrEmpty(otherNumber))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid othernumber format.");
                return false;
            }
        }
    }

    public static class DatabaseHelper
    {
        private static readonly string ConnectionString = "Data Source=DESKTOP-HPGI7KC;Initial Catalog=ContactSystemDB;Integrated Security=True;";

        public static SqlConnection GetOpenConnection()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            return connection;
        }

        public static void CloseConnection(SqlConnection connection)
        {
            if (connection != null && connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }

    public class ContactDataAccess
    {
        public void AddContact(Contact contact)
        {
            using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
            using (SqlCommand cmd = new SqlCommand("INSERT INTO ContactTabl (Name, PhoneNumber, FullName, NickName, EmailAddress, Age, Gender, WorkSpace, Facbook, OtherPhoneNumber, [Group], Street, PostalCode, Country, City) " + "VALUES (@Name, @PhoneNumber, @FullName, @NickName, @EmailAddress, @Age, @Gender, @WorkSpace, @Facbook, @OtherPhoneNumber, @Group, @Street, @PostalCode, @Country, @City)", connection))
            {
                cmd.Parameters.AddWithValue("@Name", contact.Name);
                cmd.Parameters.AddWithValue("@PhoneNumber", contact.PhoneNumber);
                cmd.Parameters.AddWithValue("@Group", "");
                cmd.Parameters.AddWithValue("@FullName", "");
                cmd.Parameters.AddWithValue("@EmailAddress", "");
                cmd.Parameters.AddWithValue("@Street", "");
                cmd.Parameters.AddWithValue("@City", "");
                cmd.Parameters.AddWithValue("@PostalCode", "");
                cmd.Parameters.AddWithValue("@Country", "");
                cmd.Parameters.AddWithValue("@Age", "");
                cmd.Parameters.AddWithValue("@Gender", "");
                cmd.Parameters.AddWithValue("@Facbook", "");
                cmd.Parameters.AddWithValue("@WorkSpace", "");
                cmd.Parameters.AddWithValue("@NickName", "");
                cmd.Parameters.AddWithValue("@OtherPhoneNumber", "");
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateContact(DetailedContact detailedContact)
        {
             using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
            using (SqlCommand cmd = new SqlCommand("UPDATE ContactTabl SET Name=@Name, PhoneNumber=@PhoneNumber, FullName=@FullName, NickName=@NickName, EmailAddress=@EmailAddress, Age=@Age, Gender=@Gender, WorkSpace=@WorkSpace, Facbook=@Facbook, OtherPhoneNumber=@OtherPhoneNumber, [Group]=@Group, Street=@Street, PostalCode=@PostalCode, Country=@Country, City=@City WHERE PhoneNumber=@PhoneNumber", connection))
            {
                cmd.Parameters.AddWithValue("@Name", detailedContact.Name);
                cmd.Parameters.AddWithValue("@PhoneNumber", detailedContact.PhoneNumber);
                cmd.Parameters.AddWithValue("@Group", detailedContact.Group?.GroupName ?? "");
                cmd.Parameters.AddWithValue("@FullName", detailedContact.FullName);
                cmd.Parameters.AddWithValue("@EmailAddress", detailedContact.EmailAddress);
                cmd.Parameters.AddWithValue("@Street", detailedContact.Address.Street);
                cmd.Parameters.AddWithValue("@City", detailedContact.Address.City);
                cmd.Parameters.AddWithValue("@PostalCode", detailedContact.Address.PostalCode);
                cmd.Parameters.AddWithValue("@Country", detailedContact.Address.Country);
                cmd.Parameters.AddWithValue("@Age", detailedContact.Age);
                cmd.Parameters.AddWithValue("@Gender", detailedContact.Gender);
                cmd.Parameters.AddWithValue("@Facbook", detailedContact.Facebook);
                cmd.Parameters.AddWithValue("@WorkSpace", detailedContact.WorkSpace);
                cmd.Parameters.AddWithValue("@NickName", detailedContact.NickName);
                cmd.Parameters.AddWithValue("@OtherPhoneNumber", detailedContact.OtherNumber);

                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteContact(string phoneNumber)
        {
            using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
            using (SqlCommand cmd = new SqlCommand("DELETE FROM ContactTabl WHERE PhoneNumber = @PhoneNumber", connection))
            {
                cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                cmd.ExecuteNonQuery();
            }
        }
        public void AddDetailedContact(DetailedContact detailedContact)
        {
            using (SqlConnection connection = DatabaseHelper.GetOpenConnection())
            using (SqlCommand cmd = new SqlCommand("UPDATE ContactTabl SET Name=@Name, PhoneNumber=@PhoneNumber, FullName=@FullName, NickName=@NickName, EmailAddress=@EmailAddress, Age=@Age, Gender=@Gender, WorkSpace=@WorkSpace, Facbook=@Facbook, OtherPhoneNumber=@OtherPhoneNumber, [Group]=@Group, Street=@Street, PostalCode=@PostalCode, Country=@Country, City=@City WHERE PhoneNumber=@PhoneNumber", connection))
            {
                cmd.Parameters.AddWithValue("@Name", detailedContact.Name);
                cmd.Parameters.AddWithValue("@PhoneNumber", detailedContact.PhoneNumber);
                cmd.Parameters.AddWithValue("@Group", detailedContact.Group?.GroupName ?? "");
                cmd.Parameters.AddWithValue("@FullName", detailedContact.FullName);
                cmd.Parameters.AddWithValue("@EmailAddress", detailedContact.EmailAddress);
                cmd.Parameters.AddWithValue("@Street", detailedContact.Address.Street);
                cmd.Parameters.AddWithValue("@City", detailedContact.Address.City);
                cmd.Parameters.AddWithValue("@PostalCode", detailedContact.Address.PostalCode);
                cmd.Parameters.AddWithValue("@Country", detailedContact.Address.Country);
                cmd.Parameters.AddWithValue("@Age", detailedContact.Age);
                cmd.Parameters.AddWithValue("@Gender", detailedContact.Gender);
                cmd.Parameters.AddWithValue("@Facbook", detailedContact.Facebook);
                cmd.Parameters.AddWithValue("@WorkSpace", detailedContact.WorkSpace);
                cmd.Parameters.AddWithValue("@NickName", detailedContact.NickName);
                cmd.Parameters.AddWithValue("@OtherPhoneNumber", detailedContact.OtherNumber);

                cmd.ExecuteNonQuery();
            }
        }


    }



    internal class Program
    {
        static void Main()
        {

        }

    }
}
