﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        /*public struct ImperialMeasurement
        {
            public float feet;
            public ImperialMeasurement(float r)
            {
                this.feet = r;
            }

            public static explicit operator ImperialMeasurement(int m)//this method must be staticand since we want to express  
                                                                      //an explicit user define conversion we must use the explicit key word
                                                                      //and should be given the same name of the class in which it resides
            {
                float conversionResult = 3.28f * m;
                ImperialMeasurement temp = new ImperialMeasurement(conversionResult);
                return temp;
            }
        }*/
        static void Main(string[] args)
        {
           /* Console.WriteLine("please entre the number");
            int mm=Convert.ToInt32(Console.ReadLine());
            ImperialMeasurement im = (ImperialMeasurement)mm;//we could coverse it it implicit by removing the explicit conversion code and also change explicit to implicit  
            Console.WriteLine($"the measurement of {mm} in meters is {im.feet} in feet");
            Console.ReadKey();*/

        }
    }
}
