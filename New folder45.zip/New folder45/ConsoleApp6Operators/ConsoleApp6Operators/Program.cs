﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6Operators
{
    public class Rectangle
    {
        public int width;
        public int height;

        public Rectangle(int width, int height)
        {
            this.width = width;
            this.height = height;
        }
        public static Rectangle operator +(Rectangle r1, Rectangle r2)
        {
            int w = r1.width + r2.width;
            int h = r1.height + r2.height;
            Rectangle rectResult = new Rectangle(w, h);
            //Rectangle rectResult=new Rectangle(r1.width+r2.width,r1.height+r2.height);
            return rectResult;
        }
        internal class Program
    {
        
        }
        static void Main(string[] args)
        {
            Rectangle r1 = new Rectangle(4, 5);
            Rectangle r2 = new Rectangle(4, 5);

            Rectangle rectResult3 = r1 + r2;
            Console.WriteLine($"r1(4,5) + r2(4,5) ={rectResult3.width},{rectResult3.height} ");
            Console.ReadKey();
        }
    }
}
