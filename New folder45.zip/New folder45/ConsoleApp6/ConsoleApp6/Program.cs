﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{

    class IntegerSet
    {
        private bool[] set;
        public IntegerSet()
        {
            set = new bool[101];
        }
        public void InsertElement(int k)
        {
            if (k >= 0 && k <= 100)
            {
                set[k] = true;
            }
            else Console.WriteLine($"valueout of range");
        }
        public void DeleteElement(int m)
        {
            set[m] = false;

        }
        public IntegerSet Union(IntegerSet otherSet)
        {
            IntegerSet unionSet=new IntegerSet();
            for(int i = 0; i < set.Length; i++)
            {
                unionSet.set[i] = set[i] || otherSet.set[i];
            }
            return unionSet;
        }
        public IntegerSet Intersection(IntegerSet otherSet)
        {
            IntegerSet intersection=new IntegerSet();
            for(int i = 0;i < set.Length;i++)
            {
                intersection.set[i] = set[i] && otherSet.set[i];
            }
            return intersection;
        }

        public string ConvertString()
        {
            string setString = " ";
            bool isEmpty = false;
            return setString;

        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {



        }
    }
}
