﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    public class Test
    {

        public int a;
        public double Average(int x, int y, int z)
        {
            double Avg;
            Avg=(x+y+z)/3.0;
            return Avg;
        }
    }


    internal class MyTest
    {
        static void Main(string[] args)
        {
            Test t = new Test();
            t.a = 20;
            double result = t.Average(10, 20, 30);
            Console.WriteLine("the result is {0}",result);

            
        }
    }
}
